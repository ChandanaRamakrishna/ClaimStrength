**pie title Claim Strength**
    "Strong" : 5
    "Moderate" : 1
    "Weak" : 0

**pie title Source Types**
    "Academic/Journal" : 9
    "Web/Industry" : 3
